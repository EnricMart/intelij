import java.util.Random;
        public class Main {
            public static void main(String[] args) {
                Random random = new Random();
                String name;
                final int MIN =40;
                final int MAX =60;
                boolean exit = false;
                boolean errorcondition = false;
                int energy = random.nextInt(MAX - MIN) + MIN;
                int fatigue = random.nextInt(MAX - MIN) + MIN;
                int sleep = random.nextInt(MAX - MIN) + MIN;
                int hygiene = random.nextInt(MAX - MIN) + MIN;
                int weight = random.nextInt(MAX - MIN) + MIN;
                char mascota;
                do{
                    System.out.print("Which pet do you want to be" + "\nD=Dog" + "\nC=Cat" + "\n:");
                mascota = Character.toUpperCase(Teclat.llegirChar());
                if (mascota == 'D') {
                    System.out.println(Animal.perro);
                    errorcondition = true;
                } else if (mascota == 'C') {
                    System.out.println(Animal.cat);
                    errorcondition = true;
                } else {
                    System.out.println("You have chosen a wrong pet");

                }
            } while (!errorcondition);


                int accionPet;
                System.out.print("Choose the name of your pet:");
                name=Teclat.llegirString();
                System.out.println("\nThe stats of  "+name + " are: " +"\nenergy= "+energy +"\nfatigue= "+fatigue +"\nsleep= "+ sleep + "\nhygiene= "+hygiene+"\nweight= "+weight);
            do {
                System.out.println("----------------------------------------------------"+"\n1.- Sleep\n"+"2.- Play\n"+"3.- Eat");
                if (mascota=='D') {
                    System.out.println("4.- Shower\n" + "0.- Exit application" + "\n----------------------------------------------------");
                }
                else if (mascota=='C') {
                    System.out.println("4.- Self-cleaning\n"+"0.- Exit application\" + \"\\n----------------------------------------------------");
                }
                System.out.print("Choose an option: ");
                accionPet=Teclat.llegirInt();
                switch (accionPet) {
                    case 1:
                        fatigue -= 15;
                        energy += 15;
                        if (mascota == 'D') {
                            sleep-=25;
                        } else if (mascota == 'C') {
                            sleep -= 20;
                        }
                        break;
                    case 2:
                        fatigue+=10;
                        energy-=10;
                        hygiene-=15;
                        weight-=10;
                        if (mascota == 'D') {
                            sleep-= 10;
                        } else if (mascota == 'C') {
                            sleep+=15;
                        }
                        break;
                    case 3:
                        fatigue-= 15;
                        energy+=10;
                        hygiene-=10;
                        weight+=10;
                        if (mascota == 'D') {
                            sleep+=15;
                        } else if (mascota == 'C') {
                            sleep+=10;
                        }
                        break;
                    case 4:
                        hygiene += 20;
                        if (mascota=='D') {
                            sleep -= 15;
                        }
                        else if (mascota=='C') {
                            sleep += 10;
                        }
                        break;
                    case 0:
                        System.out.println("Good bye"+"\nYour final stats were: ");
                        exit = true;
                }   System.out.println("energy = " + energy + "\nfatigue = " + fatigue + "\nsleep = " + sleep + "\nhygiene = " + hygiene + "\nweight = " + weight);
                if (energy<=0||energy>=100) {
                    System.out.println("Your pet couldnt live more with that level of energy");
                    exit=true;
                }
                else if (fatigue<=0||fatigue>=100) {
                    System.out.println("Your pet couldn't live more with that level of fatigue");
                    exit=true;
                }
                else if (sleep<=0||sleep>=100) {
                    System.out.println("Your pet couldn't live more with that level of sleep");
                    exit=true;
                }
                else if (hygiene<=0||hygiene>=100) {
                    System.out.println("Your pet couldn't live more with that level of hygiene");
                    exit=true;
                }
                else if (weight<=0||weight>=100) {
                    System.out.println("Your pet couldn't live more with that level of weight");
                    exit=true;
                }

            }while(!exit);
            }

        }








